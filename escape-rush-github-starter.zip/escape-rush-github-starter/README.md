# Escape Rush — GitHub setup

This is a setup kit, **not the Escape Rush game source**. To preserve the existing playable game, connect the original Lovable project directly to GitHub:

https://lovable.dev/projects/59b5b512-802c-4ccf-8053-236d00bd7d94

In Lovable, find the GitHub integration and connect a repository. Confirm all project files are present on GitHub before editing.

## Free local development

Once the original repository is synced, clone it and run:

```bash
npm install
npm run dev
```

Create a branch such as `dev/retry-ui` for each revision. Test changes before merging to the default branch. The original project uses React, TypeScript and Vite, not a standalone HTML app.

## Free publishing

Cloudflare Pages can host compatible static Vite builds on its free tier, but this particular project uses TanStack Start and may need an appropriate runtime adapter. Do not assume a static `dist` folder or GitHub Pages will support the app without reviewing the build and server routes. Avoid connecting production deployments until testing is complete.

## No-spend rule

Never invoke Lovable AI, deploy from Lovable, purchase credits, or merge changes to production without explicit approval. Lovable GitHub sync may reflect edits automatically; use a separate branch and review any synchronization behavior before pushing.

## First revision scope

1. SLIMED! transitions to Retry? at the exact failed location.
2. Retain frozen failure state and preserve same-level Retry.
3. Reduce early-level border shortcuts; no T-junctions before level 21.
4. Faster/thicker slime for early complete paths.

The game source itself must come from the original Lovable-to-GitHub integration, not this kit.
